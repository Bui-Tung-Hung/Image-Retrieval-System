import open_clip

# Xem tất cả pretrained models
open_clip.list_pretrained()
